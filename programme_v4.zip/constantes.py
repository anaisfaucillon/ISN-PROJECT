nombre_sprite_cote = 25
taille_sprite = 20
largeur = 1200
longeur = 800

titre_fenetre = "Menu"
image_icone = "image\evo.png"
image_accueil = "image\menuA.png"
image_accueilB = "image\menuD.png"
image_accueilC = "image\parcoursup.png"
image_accueilE = "image\parcoursupE.png"
image_accueilF = "image\parcoursupF.png"
image_accueilG = "image\parcoursupG.png"
image_accueilH = "image\parcoursupH.png"
image_perso = "image\perso4.png"
image_persoB = "image\perso5.png"

image_niveau = "image\evo.png"
image_end = "image\end.png"
image_fond = "image\menuB.png"
